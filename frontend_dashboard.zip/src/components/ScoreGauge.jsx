import { RadialBarChart, RadialBar } from "recharts";

export default function ScoreGauge({ score }) {
  const data = [{ name: "score", value: score, fill: "#3b82f6" }];

  return (
    <RadialBarChart
      width={250}
      height={250}
      innerRadius="70%"
      outerRadius="100%"
      data={data}
      startAngle={180}
      endAngle={0}
    >
      <RadialBar minAngle={15} background clockWise dataKey="value" />
    </RadialBarChart>
  );
}