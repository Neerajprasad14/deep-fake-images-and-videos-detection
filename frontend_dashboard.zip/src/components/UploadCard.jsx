import axios from "axios";
import { useState } from "react";

export default function UploadCard({ setResult }) {
  const [file, setFile] = useState(null);
  const [text, setText] = useState("");

  const submitData = async () => {
    const formData = new FormData();
    if (file) formData.append("file", file);
    if (text) formData.append("text", text);

    const res = await axios.post("http://localhost:8000/analyze", formData);
    setResult(res.data);
  };

  return (
    <div className="bg-slate-900 p-6 rounded-2xl shadow-xl">
      <h2 className="text-2xl mb-4">Upload Content</h2>

      <textarea
        placeholder="Paste text here..."
        className="w-full p-3 rounded bg-slate-800 mb-4"
        onChange={(e) => setText(e.target.value)}
      />

      <input
        type="file"
        className="mb-4"
        onChange={(e) => setFile(e.target.files[0])}
      />

      <button
        onClick={submitData}
        className="bg-blue-600 px-4 py-2 rounded hover:bg-blue-700"
      >
        Analyze
      </button>
    </div>
  );
}