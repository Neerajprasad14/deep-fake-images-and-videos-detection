import ScoreGauge from "./ScoreGauge";

export default function ResultPanel({ result }) {
  if (!result) {
    return (
      <div className="bg-slate-900 p-6 rounded-2xl shadow-xl">
        <h2 className="text-2xl">Results</h2>
        <p className="text-slate-400 mt-4">No analysis yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 p-6 rounded-2xl shadow-xl">
      <h2 className="text-2xl mb-4">Analysis Result</h2>

      <ScoreGauge score={result.authenticity_score} />

      <div className="mt-6 space-y-2">
        <p>🧠 NLP Verdict: {result.nlp_verdict}</p>
        <p>🖼️ Image Check: {result.image_verdict}</p>
        <p>🎥 Video Check: {result.video_verdict}</p>
        <p>🌐 Source Credibility: {result.source_score}</p>
      </div>
    </div>
  );
}