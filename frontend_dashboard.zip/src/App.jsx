import UploadCard from "./components/UploadCard";
import ResultPanel from "./components/ResultPanel";
import { useState } from "react";

export default function App() {
  const [result, setResult] = useState(null);

  return (
    <div className="min-h-screen p-10">
      <h1 className="text-4xl font-bold mb-8 text-center">
        AI Content Authenticity Dashboard
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <UploadCard setResult={setResult} />
        <ResultPanel result={result} />
      </div>
    </div>
  );
}