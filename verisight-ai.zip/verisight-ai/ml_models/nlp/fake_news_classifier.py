from transformers import pipeline

classifier = pipeline("text-classification", model="roberta-base")

def classify_text(text: str):
    result = classifier(text[:512])[0]
    return result['score'] if result['label'] == 'LABEL_1' else 1 - result['score']
