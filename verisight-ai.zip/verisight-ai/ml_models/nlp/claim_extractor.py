import spacy

nlp = spacy.load("en_core_web_sm")

def extract_claims(text: str):
    doc = nlp(text)
    claims = [sent.text for sent in doc.sents]
    return claims
