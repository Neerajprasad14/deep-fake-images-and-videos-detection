from PIL import Image
from io import BytesIO

def check_exif(image_bytes):
    try:
        image = Image.open(BytesIO(image_bytes))
        exif = image._getexif()
        return exif is not None
    except:
        return False
