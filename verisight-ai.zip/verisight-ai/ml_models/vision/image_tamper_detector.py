import cv2
import numpy as np
from PIL import Image
from io import BytesIO

def detect_tamper(image_bytes):
    image = Image.open(BytesIO(image_bytes)).convert('RGB')
    img = np.array(image)

    ela = cv2.convertScaleAbs(img, alpha=1.5, beta=10)
    score = np.mean(ela) / 255

    return float(score)
