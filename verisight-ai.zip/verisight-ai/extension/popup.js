document.getElementById("verifyBtn").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    
    const response = await fetch("http://localhost:8000/verify", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ url: tab.url })
    });

    const data = await response.json();
    document.getElementById("result").innerText = JSON.stringify(data, null, 2);
});
