def fuse_results(text, image, source):
    t = text.get("linguistic_trust", 0.5)
    f = text.get("fact_match", 0.5)
    s = source.get("source_score", 0.5)
    i = 1 - image.get("manipulation_probability", 0.5)

    score = 0.3*t + 0.3*f + 0.2*s + 0.2*i

    return {
        "final_confidence": round(score, 2),
        "verdict": "Likely Authentic" if score > 0.7 else "Suspicious"
    }
