from fastapi import FastAPI
from routes.verify_route import router as verify_router

app = FastAPI(title="VeriSight AI")

app.include_router(verify_router)

@app.get("/")
def root():
    return {"message": "VeriSight AI is running"}
