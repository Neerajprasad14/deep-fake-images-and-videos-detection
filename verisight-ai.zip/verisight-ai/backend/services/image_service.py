from ml_models.vision.image_tamper_detector import detect_tamper
from ml_models.vision.exif_analyzer import check_exif

def analyze_image(image_bytes):
    tamper_prob = detect_tamper(image_bytes)
    exif_ok = check_exif(image_bytes)

    return {
        "manipulation_probability": tamper_prob,
        "metadata_authentic": exif_ok
    }
