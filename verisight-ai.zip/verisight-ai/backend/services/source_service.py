def analyze_source(url: str):
    if "wikipedia" in url or "gov" in url:
        score = 0.9
    else:
        score = 0.5

    return {"source_score": score}
