from ml_models.nlp.fake_news_classifier import classify_text
from ml_models.nlp.claim_extractor import extract_claims

def analyze_text(text: str):
    fake_score = classify_text(text)
    claims = extract_claims(text)

    return {
        "linguistic_trust": 1 - fake_score,
        "claims": claims,
        "fact_match": 0.7
    }
