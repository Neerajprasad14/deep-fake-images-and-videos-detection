from fastapi import APIRouter, UploadFile, File
from services.text_service import analyze_text
from services.image_service import analyze_image
from services.source_service import analyze_source
from fusion_engine.fusion_model import fuse_results

router = APIRouter()

@router.post("/verify")
async def verify(text: str = "", image: UploadFile = File(None), url: str = ""):
    text_result = analyze_text(text) if text else {}
    image_result = analyze_image(await image.read()) if image else {}
    source_result = analyze_source(url) if url else {}

    final = fuse_results(text_result, image_result, source_result)
    return final
